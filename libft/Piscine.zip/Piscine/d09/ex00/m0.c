void	ft_generic(void);

int main(void)
{
	ft_generic();
	return (0);
}
