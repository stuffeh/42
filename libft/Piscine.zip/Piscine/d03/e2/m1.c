/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   m1.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 18:52:46 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 18:55:31 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "../lib/ft_putchar.c"
#include "ft_swap.c"

int		main(void)
{
	//int *num1 = &num;
    int num;
    int num1;
    int num2;
/*    int ***num3;
    int ****num4;
    num =42;
    num1 = &num;
    num2 = &num1;
    num3 = &num2;
    num4 = &num3;
*/
    num1 = 42;
    num2 = 55;


	num = 0;
	ft_swap(&num1, &num2);
	ft_putchar(num1);
	return (0);
}
