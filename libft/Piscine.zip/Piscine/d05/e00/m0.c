/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   m0.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/15 16:47:14 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/15 17:37:17 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *str);

int 	ft_putchar(char c);

int		main(int argc, char **argv)
{
	char arg = argc + 48;
	ft_putchar(arg);
	ft_putchar('\n');
	if (argc != 1)
	{
		argv++;
		ft_putstr(*argv);	
	}
	return 0;
}
