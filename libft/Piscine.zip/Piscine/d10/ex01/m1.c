/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_foreach.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/22 16:40:42 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/22 16:41:17 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
void	ft_putnbr(int nb);

void	ft_foreach(int *tab, int length, void (*f)(int));

int main(void)
{
	int tab[10] = {0,1,2,3,4,5,6,7,8,9};
	ft_foreach(tab, 10, &ft_putnbr);
	return 0;
}