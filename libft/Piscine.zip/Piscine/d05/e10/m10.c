#include <stdio.h>
//#include <string.h>


char		*ft_strcapitalize(char *str);

int		main()
{

//	char 	find[4] = "assd";
	char 	strin[] = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
	char 	*temp = ft_strcapitalize(strin);
	printf("temp: %s\n", temp);
	printf("final: %s\n", strin);


/*	char *ds = "asdfdddd";
	const char *sr = "zxcx";
	size_t si = 3;
	printf("cat: %lu", strlcat(ds, sr, si));
	return 0;
*/
}


// %s = string
// %d = int

// %f = double
// %c = char
