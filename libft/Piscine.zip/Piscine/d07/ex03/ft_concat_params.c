/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_concat_params.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/18 20:51:55 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/18 20:51:58 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int		ft_strlen(char *str)
{
	int count;

	count = 0;
	while (str[count])
	{
		count++;
	}
	return (count);
}

void	ft_strcpy(char *dest, char *src, int *posd, int count)
{
	int pos;

	pos = 0;
	while (src[pos])
	{
		dest[*posd] = src[pos];
		pos++;
		*posd = *posd + 1;
	}
	if (*posd < count)
	{
		dest[*posd] = '\n';
		*posd = *posd + 1;
	}
	else
	{
		dest[*posd] = '\0';
	}
}

char	*ft_concat_params(int argc, char **argv)
{
	char	*str;
	int		i;
	int		k;
	int		count;

	i = 1;
	count = 0;
	while (i < argc)
	{
		count += ft_strlen(argv[i]) + 1;
		i++;
	}
	count--;
	str = (char*)malloc(sizeof(char) * count);
	i = 1;
	k = 0;
	str[0] = '\0';
	while (argv[i])
	{
		ft_strcpy(str, argv[i], &k, count);
		i++;
	}
	return (str);
}
