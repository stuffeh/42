#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int 	ft_atoi(char *str);

int		ft_putchar(char c);

int main()
{
//    double t = 7.836;
//    int test = 5;
//    printf("%.2f", t);
    int a = ft_atoi("\n\n\n\n\n\n\n\n\n\n"
			"\n\n\n\n\n\n\n\n\n\n"
			"\n\n\n\n\n\n\n\n\n\n"
			"\n\n\n\n\n\n\n\n\n\n"
			"\n\n\n\n\n\n\n\n\n\n"
			"\n\n\n\n\n\n\n\n\n\n"
			"\n\n\n\n\n\n\n\n\n\n"
			"\n\n\n\n\n\n\n\n\n\n"
			"55");
	int b = 2147483647;

	b=b*-1;
 //   printf("%d hello %d %s", test, test, "tim");
	printf("%d\n", a);
    printf("%d\n", ft_atoi("21474849"));
    printf("%d\n", ft_atoi("-21483647"));
    printf("%d\n", ft_atoi("-2183648"));
    printf("%d\n", ft_atoi("-483649"));
	printf("%d", ft_atoi("   \n 00000042"));

// 	ft_putchar('\n');
    return 0;

}


// %s = string
// %d = int

// %f = double
// %c = char
