/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   m5.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/19 04:49:00 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/19 04:49:03 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_antidote(int i, int j, int k);

int main(void)
{
	printf("%d", ft_antidote(3, 5, 6));
	printf("%d", ft_antidote(5, 3, 6));
	printf("%d", ft_antidote(3, 6, 5));
	printf("%d", ft_antidote(6, 5, 3));
	printf("%d", ft_antidote(6, 3, 5));
	printf("%d", ft_antidote(5, 6, 3));

}