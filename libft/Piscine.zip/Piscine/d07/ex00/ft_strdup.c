/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 18:52:46 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 18:55:31 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strdup(char *src)
{
	char	*dupe;
	int		len;

	len = 0;
	while (src[len])
	{
		len++;
	}

	dupe = (char*)malloc(sizeof(*dupe) * (len + 1));
	len = 0;
	while (src[len])
	{
		dupe[len] = src[len];
		len++;
	}
	dupe[len] = src[len];
	return (dupe);
}
