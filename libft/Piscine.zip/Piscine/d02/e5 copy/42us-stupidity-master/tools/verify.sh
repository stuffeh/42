#!/bin/sh

 norminette -R CheckForbiddenSourceHeader