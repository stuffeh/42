/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_takes_place.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/18 19:19:46 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/18 20:47:21 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ty_ampm(int hour)
{
	hour = hour % 24;
	if (hour >= 12)
	{
		return ("P.M.");
	}
	else
	{
		return ("A.M.");
	}
}

int		ty_hour(int hour)
{
	hour = hour % 24;
	if (hour == 0)
	{
		hour = 24;
	}
	if (hour > 12)
	{
		return (hour - 12);
	}
	else
	{
		return (hour);
	}
}

void	ft_takes_place(int hour)
{
	printf("THE FOLLOWING TAKES PLACE BETWEEN ");
	printf("%d.00 %s AND ", ty_hour(hour), ty_ampm(hour));
	printf("%d.00 %s\n", ty_hour(hour + 1), ty_ampm(hour + 1));
}
