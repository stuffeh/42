/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   m0.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/23 22:33:33 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/23 22:36:00 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>
#include "ft_list.h"

void	ft_putstr(char *str);
int		ft_list_size(t_list *begin_list);

t_list	*add_link(t_list *list, char *str)
{
	t_list *tmp;

	tmp = malloc(sizeof(t_list));
	if (tmp)
	{
		tmp->str = str;
		tmp->next = list;
	}
	return (tmp);
}

void	print_list(t_list *list)
{
	while (list)
	{
		ft_putstr(list->str);
		list = list->next;
	}
}

int		main(void)
{
	t_list *list;
	t_list **list1;

	list1 = &list;
	list = NULL;
	list = add_link(list, "toto\n");
	list = add_link(list, "tata\n");
	list = add_link(list, "tutu\n");
	ft_list_push_front(list1, "dada\n");
	print_list(list);
	printf("size: %d\n", ft_list_size(list));
	list = ft_create_elem("dodo\n");
	print_list(list);
	return (0);
}
