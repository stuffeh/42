/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_file.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 18:52:46 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 18:55:31 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>

void	ty_putchar(char c)
{
	write(1, &c, 1);
}

void	ty_putstr(char *str)
{
	while (*str)
	{
		ty_putchar(*str);
		str++;
	}
}

int		main(int argc, char **argv)
{
	int		file;
	char	c;

	if (argc < 2)
	{
		ty_putstr("File name missing.\n");
	}
	else if (argc > 2)
	{
		ty_putstr("Too many arguments.\n");
	}
	else
	{
		file = open(argv[1], O_RDONLY);
		if (file < 0)
			return (0);
		while (read(file, &c, 1))
		{
			ty_putchar(c);
		}
	}
	return (0);
}
