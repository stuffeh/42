# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    libft_creator.sh                                   :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: tyeung <marvin@42.fr>                      +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2019/07/17 19:05:38 by tyeung            #+#    #+#              #
#    Updated: 2019/07/17 19:05:48 by tyeung           ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#!/bin/sh
gcc -c -Wall -Werror -Wextra ft_putchar.c ft_putstr.c ft_strcmp.c ft_strlen.c ft_swap.c
ar cr libft.a ft_putchar.o ft_putstr.o ft_strcmp.o ft_strlen.o ft_swap.o
ranlib libft.a
rm ft_putchar.o ft_putstr.o ft_strcmp.o ft_strlen.o ft_swap.o
