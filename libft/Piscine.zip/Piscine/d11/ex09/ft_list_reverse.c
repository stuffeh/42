/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_reverse.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/23 22:07:15 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/23 22:07:18 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_list.h"

void	ft_list_reverse(t_list **begin_list)
{
	t_list	*current;
	t_list	*temp;
	t_list	*previous;

	current = *begin_list;
	previous = NULL;
	temp = NULL;
	while (current)
	{
		temp = current->next;
		current->next = previous;
		previous = current;
		current = temp;
	}
	*begin_list = previous;
}
