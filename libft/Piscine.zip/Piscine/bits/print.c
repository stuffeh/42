/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/31 11:40:53 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/31 11:40:56 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <unistd.h>
#include <stdio.h>


/*
** First Method is standard while the second one use bitwise operators
*/

void	print_bits(unsigned char octet)
{
	int	i;

	i = 128;
	while (octet >= 0 && i)
	{
		(octet / i) ? write(1, "1", 1) : write(1, "0", 1);
		(octet / i) ? octet -= i : 0;
		i /= 2;
	}
}

void	print_bits2(unsigned char octet)
{
	int	i = 128;
	while (i >= 1)
	{
		printf("oct:%d, i:%d\n", octet, i);
//		write(1, "\n", 1);
		if ((octet & i))
		{
			write(1, "1", 1);
		}
		else
		{
			write(1, "0", 1);
		}
		i = i>>1;
	}
//		(octet & i) ? write(1, "1", 1) : write(1, "0", 1);
}

int		main(void)
{
	int n = 221;
	print_bits(n);
	write(1, "\n", 1);
	print_bits2(n);
    write(1, "\n", 1);
}