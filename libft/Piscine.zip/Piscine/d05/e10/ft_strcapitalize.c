/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/15 21:46:18 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/15 21:46:21 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		checkcaps(char c)
{
	if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
		|| (c >= '0' && c <= '9'))
		return (1);
	return (0);
}

char	*ft_strcapitalize(char *str)
{
	int index;

	index = 0;
	while (str[index])
	{
		if (index == 0 || !checkcaps(str[index - 1]))
		{
			if ((str[index] >= 'a' && str[index] <= 'z'))
				str[index] -= 32;
		}
		else if ((str[index] >= 'A' && str[index] <= 'Z'))
			str[index] += 32;
		index++;
	}
	return (str);
}
