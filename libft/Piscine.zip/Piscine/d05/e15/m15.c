#include <stdio.h>
//#include <string.h>


int		ft_str_is_printable(char *str);

int		main()
{

//	char 	find[4] = "assd";
	char 	strin[] = "FOURT!Y";
	int 	temp = ft_str_is_printable(strin);
	printf("temp: %d\n", temp);
	printf("final: %s\n", strin);


/*	char *ds = "asdfdddd";
	const char *sr = "zxcx";
	size_t si = 3;
	printf("cat: %lu", strlcat(ds, sr, si));
	return 0;
*/
}


// %s = string
// %d = int

// %f = double
// %c = char