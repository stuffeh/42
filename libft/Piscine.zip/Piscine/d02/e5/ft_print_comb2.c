/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 20:05:47 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 20:05:54 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);

void	ft_print_comb2(void)
{
	int comb[2];

	comb[0] = 0;
	while (comb[0] <= 98)
	{
		comb[1] = comb[0] + 1;
		while (comb[1] <= 99)
		{
			ft_putchar(comb[0] / 10 + 48);
			ft_putchar(comb[0] % 10 + 48);
			ft_putchar(' ');
			ft_putchar(comb[1] / 10 + 48);
			ft_putchar(comb[1] % 10 + 48);
			if (!(comb[0] == 98 && comb[1] == 99))
			{
				ft_putchar(',');
				ft_putchar(' ');
			}
			comb[1]++;
		}
		comb[0]++;
	}
}
