/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/22 17:50:10 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/22 17:50:13 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		*ft_map(int *tab, int length, int(*f)(int))
{
	int i;
	int	*dump;
	
	i = 0;
	if (!(dump = (int*)malloc(sizeof(int) * length + 1)))
	{
		return (0);
	}
	while(i < length)
	{
		dump[i] = f(tab[i]);
		i++;
	}
	return dump;
}
