/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/15 21:46:18 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/15 21:46:21 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
//#include <string.h>


char	*ft_strcat(char *dest, char	*src);

int		main()
{

	char 	find[] = "assd";
	char 	strin[] = "FOURT!Y";
	char 	*temp = ft_strcat(strin, find);
	printf("temp: %s\n", temp);
	printf("final: %s\n", strin);


/*	char *ds = "asdfdddd";
	const char *sr = "zxcx";
	size_t si = 3;
	printf("cat: %lu", strlcat(ds, sr, si));
	return 0;
*/
}


// %s = string
// %d = int

// %f = double
// %c = char