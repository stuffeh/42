#include <unistd.h>
#include <stdio.h>

int	ft_putchar(char c);

void ft_putnbr(int nb);

int main()
{
//    double t = 7.836;
//    int test = 5;
//    printf("%.2f", t);
    ft_putnbr(2147483647);
 //   printf("%d hello %d %s", test, test, "tim");
 	ft_putchar('\n');
 	ft_putnbr(-2147483648);
    return 0;

}


// %s = string
// %d = int

// %f = double
// %c = char