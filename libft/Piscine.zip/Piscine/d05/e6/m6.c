#include <stdio.h>
//#include <string.h>


int		ft_strcmp(char *s1, char *s2);

int		main()
{
//    double t = 7.836;
//    int test = 5;
//    printf("%.2f", t);
 //   printf("%d hello %d %s", test, test, "tim");

	char 	find[4] = "assd";
	char 	strin[4] = "assd";
	int 	temp = ft_strcmp(strin, find);
	printf("temp: %d\n", temp);
	printf("final: %s\n", strin);


/*	char *ds = "asdfdddd";
	const char *sr = "zxcx";
	size_t si = 3;
	printf("cat: %lu", strlcat(ds, sr, si));
	return 0;
*/
}


// %s = string
// %d = int

// %f = double
// %c = char