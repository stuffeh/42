/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_foreach.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/22 16:40:42 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/22 16:41:17 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int	ft_atoi(char *str);

char	ft_is_sort(int *tab, int length, int (*f)(int,int));

int main(void)
{
	char *cha = "0123456789";
	//char **cha2 = *cha;
	
	printf("%d\n", ft_is_sort(&cha, 10, &ft_atoi));
	return (0);
}