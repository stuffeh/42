//#include <unistd.h>
#include <stdio.h>
//#include <string.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n);

//int		ft_putchar(char c);

int main()
{
//    double t = 7.836;
//    int test = 5;
//    printf("%.2f", t);
//	printf("%d hello %d %s", test, test, "tim");
	//printf("%s hello ", ft_strcpy());
	char origin[] = "asdfffff";
	char final[] = "1111";
	unsigned int count = 6;

//	origin = "asdf";
//	final = "";

	char *temp = ft_strncpy(final, origin, count);
	printf("temp: %s\n", temp);
	printf("final: %s", final);
 //	ft_putchar('\n');
    return 0;

}

// %s = string
// %d = int

// %f = double
// %c = char