#include <stdio.h>
//#include <string.h>


char		*ft_strupcase(char *str);

int		main()
{
//    double t = 7.836;
//    int test = 5;
//    printf("%.2f", t);
 //   printf("%d hello %d %s", test, test, "tim");

//	char 	find[4] = "assd";
	char 	strin[] = "FoUrTy Twoo";
//	unsigned int a = 3;
	char 	*temp = ft_strupcase(strin);
	printf("temp: %s\n", temp);
	printf("final: %s\n", strin);


/*	char *ds = "asdfdddd";
	const char *sr = "zxcx";
	size_t si = 3;
	printf("cat: %lu", strlcat(ds, sr, si));
	return 0;
*/
}


// %s = string
// %d = int

// %f = double
// %c = char