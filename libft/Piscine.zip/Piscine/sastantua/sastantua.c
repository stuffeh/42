/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sastantua.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/14 18:54:30 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/14 18:54:57 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int		ft_putchar(char c);

void	ft_repeat(int num, char c)
{
	while (num != 0)
	{
		ft_putchar(c);
		num--;
	}
}

void	sastantua(int size)
{
	if (size < 1)
		return ;
	ft_repeat(2, ' ');
	ft_putchar('/');
	ft_putchar('*');
	ft_putchar('\\');
	ft_putchar('\n');
	ft_repeat(1, ' ');
	ft_putchar('/');
	ft_repeat(3, '*');
	ft_repeat(1, '\\');
	ft_putchar('\n');
	ft_putchar('/');
	ft_repeat(2, '*');
	ft_repeat(1, '|');
	ft_repeat(2, '*');
	ft_repeat(1, '\\');
	ft_putchar('\n');
}

int		main(int argc, char **argv)
{
	if (*argv[1] == 'b')
	{
		printf("asdf\n");
	}
	if (*argv[1] >= '0' && *argv[1] <= '9')
		sastantua(*argv[1] - 48);
	for (int i = 0; i < argc; ++i) {
//		printf("argv[%d] = %s\n", i, argv[i]);
	}
/*
	ft_putchar(**argv[0]);
	if (argc == 1)
		return;*/
}