/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   m1.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 18:52:46 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 18:55:31 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include "ft_putchar.c"
#include "ft_recursive_factorial.c"

int		main(void)
{
    printf("%d \n", ft_recursive_factorial(6));
	printf("%d \n", ft_recursive_factorial(0));
	printf("%d \n", ft_recursive_factorial(-1));
	printf("%d \n", ft_recursive_factorial(13));
	printf("%d \n", ft_recursive_factorial(12));
//    ft_putchar('\n');
//    ft_putchar('\n');
	return (0);
}
