/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   m0.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 18:52:46 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 18:55:31 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
//#include "ft_putchar.c"

char	*ft_range(int min, int max);

int		main(void)
{

	printf("%s", ft_strdup("asdf"));
	return (0);
}
