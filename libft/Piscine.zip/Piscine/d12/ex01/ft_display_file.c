/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_file.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 18:52:46 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 18:55:31 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

void	ty_putchar(char c)
{
	write(1, &c, 1);
}

void	ty_putstr(char *str)
{
	while (*str)
	{
		ty_putchar(*str);
		str++;
	}
}

int		printfile(char *str)
{
	int		file;
	char	c;

	file = open(str, O_RDWR);
	if (file < 0)
	{
		if (errno == 21)
		{
			ty_putstr("cat: ");
			ty_putstr(str);
			ty_putstr(": Is a directory\n");
		}
		else
		{
			ty_putstr("cat: ");
			ty_putstr(str);
			ty_putstr(": No such file or directory\n");
		}
		return (0);
	}
	while (read(file, &c, 1))
	{
		ty_putchar(c);
	}
	return (1);
}

int		main(int argc, char **argv)
{
	int		i;
	char	c;

	i = 1;
	if (argc < 2)
	{
		while (read(STDIN_FILENO, &c, 1) > 0)
			ty_putchar(c);
	}
	else if (*argv[i] == '-')
	{
		while (read(STDIN_FILENO, &c, 1) > 0)
			ty_putchar(c);
	}
	else
	{
		while (i < argc)
		{
			printfile(argv[i]);
			i++;
		}
	}
	return (0);
}
