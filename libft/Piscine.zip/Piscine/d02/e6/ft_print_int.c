/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 20:05:47 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 20:05:54 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void ft_print_int(int val)
{
	int length;
	int pos;
	int value = val;
	
	length = 1;
	while(value>9)
	{
		value/=10;
		length++;
	}
	pos = length;

	int numberArray[length];

	value = val;
	while (value !=0)
	{
		pos --;
		numberArray[pos] = value % 10;
//		ft_putchar(value);
		value /= 10;
	}
	pos = 0;
	while (pos < length)
	{
//		ft_putchar(pos);
		ft_putchar(numberArray[pos]+48);
		pos++;
	}
}
