/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sastantua.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/14 18:54:30 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/14 18:54:57 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_putchar(char c);

void	ft_repeat(int num, char c)
{
	while (num != 0)
	{
		ft_putchar(c);
		num--;
	}
}

void	sastantua(int size)
{
	if (size < 1)
		return ;
	ft_repeat(2, ' ');
	ft_putchar('/');
	ft_putchar('*');
	ft_putchar('\\');
	ft_putchar('\n');
	ft_repeat(1, ' ');
	ft_putchar('/');
	ft_repeat(3, '*');
	ft_repeat(1, '\\');
	ft_putchar('\n');
	ft_putchar('/');
	ft_repeat(2, '*');
	ft_repeat(1, '|');
	ft_repeat(2, '*');
	ft_repeat(1, '\\');
	ft_putchar('\n');
}
