//#include <unistd.h>
#include <stdio.h>
//#include <string.h>

char	*ft_strcpy(char *dest, char *src);

//int		ft_putchar(char c);

int main()
{
//    double t = 7.836;
//    int test = 5;
//    printf("%.2f", t);
//	printf("%d hello %d %s", test, test, "tim");
	//printf("%s hello ", ft_strcpy());
	char origin[] = "asdf";
	char final[] = "1111";

//	origin = "asdf";
//	final = "";

	char *temp = ft_strcpy(final, origin);
	printf("temp: %s\n", temp);
	printf("final: %s", final);
 //	ft_putchar('\n');
    return 0;

}

// %s = string
// %d = int

// %f = double
// %c = char