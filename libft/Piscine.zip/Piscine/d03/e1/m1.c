/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   m1.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 18:52:46 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 18:55:31 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "../lib/ft_putchar.c"
#include "ft_ultimate_ft.c"

int		main(void)
{
	//int *num1 = &num;
    int num;
    int *num1;
    int **num2;
    int ***num3;
    int ****num4;
    num =42;
    num1 = &num;
    num2 = &num1;
    num3 = &num2;
    num4 = &num3;




	num = 0;
//	ft_ultimate_ft(&num8);
	ft_putchar(num);
	return (0);
}
