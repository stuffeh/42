/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_size.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/24 21:10:20 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/24 21:10:23 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

int		ft_list_size(t_list *begin_list)
{
	int		count;

	count = 0;
	if (!begin_list)
	{
		return (0);
	}
	while (begin_list->next)
	{
		count++;
		begin_list = begin_list->next;
	}
	return (count + 1);
}
