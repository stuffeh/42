/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   m0.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/27 21:21:54 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/27 21:22:02 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int		ft_atoi(char *str);

void	ty_putchar(char c)
{
	write(1, &c, 1);
}

int		eval_expr(char	*str);

int		iswhitespace(char c)
{
	if(c <= 32 || c == 127)
	{
		return (1);
	}
	return (0);
}

int main(int argc, char **argv)
{
	int		j;
	int		count;
	char	*str;

	j = 0;
	count = 0;
	if (argc < 2)
	{
		return (0);
	}

	while(argv[1][j] != '\0')
	{
		if(iswhitespace(argv[1][j]) == 1)
		{
			ty_putchar('!');
		}
		else
		{
			count++;
			ty_putchar(argv[1][j]);
		}
		j++;
	}
	j=0;


	while(argv[1][j] != '\0')
	{
		if(iswhitespace(argv[1][j]) == 1)
		{
			ty_putchar('!');
		}
		else
		{
			count++;
			ty_putchar(argv[1][j]);
			if ((argv[1][j] == >= '0' && argv[1][j] <= '9') || )
		}
		j++;
	}
	str = malloc(sizeof(char) * count + 1);
	

	return (0);
}