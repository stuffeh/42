/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 18:52:46 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 18:55:31 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ty_putstr(char *str)
{
	while (*str)
	{
		ft_putchar(*str);
		str++;
	}
}

void	ty_swap(char *a, char *b)
{
	char x;

	x = *a;
	*a = *b;
	*b = x;
}

int		ty_strcmp(char *s1, char *s2)
{
	int index;

	index = 0;
	while (s1[index] != '\0' || s2[index] != '\0')
	{
		if (s1[index] != s2[index])
		{
			return (s1[index] - s2[index]);
		}
		index++;
	}
	return (0);
}

int		ty_nextgap(int gap)
{
	gap = (gap * 10) / 13;
	if (gap < 1)
		return (1);
	return (gap);
}

void	ty_combsort(char **str, gap)
{
	int gap = 
}

int		main(int argc, char **argv)
{
	int i;

	i = 1;
	ty_combsort(**argv, argc);

/*	while (argv[i])
	{
		if (ty_strcmp(*argv[i], *argv[i+1]))
		{
			ty_swap(*argv[i], argv[i+1]);
		}
	}
*/	ty_putstr(argv[i]);
	ft_putchar('\n');
	i++;
	return 0;
}
