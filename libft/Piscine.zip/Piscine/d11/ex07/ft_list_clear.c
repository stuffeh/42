/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_clear.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/24 22:27:25 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/24 22:27:27 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

void	ft_list_clear(t_list **begin_list)
{
	t_list		*dump;
	t_list		*head;

	head = *begin_list;
	while (head)
	{
		dump = head->next;
		free(head);
		head = dump;
	}
	*begin_list = NULL;
}
