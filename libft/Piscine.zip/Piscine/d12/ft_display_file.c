/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_file.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/10 18:52:46 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/10 18:55:31 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	while (*str)
	{
		ft_putchar(*str);
		str++;
	}
}

int		main(int argc, char **argv)
{
//	char arg = argc + 48;
	int i;
	int file;
	char c;

	i = 0;
//	ft_putchar(arg);
//	ft_putchar('\n');
/*	while (i < argc)
	{
		ft_putstr(*argv);
		ft_putchar('\n');
		argv++;
		i++;
	}*/
	if (argc < 2)
	{
		ft_putstr("File name missing.\n");
	}
	else if ( argc > 2)
	{
		ft_putstr("Too many arguments.\n");
	}
	else
	{
		ft_putstr(argv[1]);
	file = open(argv[1], O_RDONLY);
	if (file <0)
		return (0);
	
	while (read(file, &c, 1))
	{
		ft_putchar(c);
		// ft_putstr(c);
	}

	}
	return 0;
}
