/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_doop.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/27 20:34:26 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/27 20:35:15 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		do_op(int nb1, int nb2, char operator)
{
	if (operator == '+')
	{
		return (nb1 + nb2);
	}
	else if(operator == '-')
	{
		return (nb1 - nb2);
	}
	else if(operator == '*')
	{
		return (nb1 * nb2);
	}
	else if(operator == '/')
	{
		return (nb1 / nb2);
	}
	else if(operator == '%')
	{
		return (nb1 % nb2);
	}
	return (0);
}