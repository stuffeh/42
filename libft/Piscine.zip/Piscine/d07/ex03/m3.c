/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   m3.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/18 20:52:11 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/18 20:52:14 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_concat_params(int argc, char **argv);

int		main(int argc, char **argv)
{
	printf("results:%s", ft_concat_params(argc, argv));
	return (0);
}