#include <stdio.h>
#include <string.h>

char	*ft_strstr(char *str, char *to_find);

int		main()
{
//    double t = 7.836;
//    int test = 5;
//    printf("%.2f", t);
 //   printf("%d hello %d %s", test, test, "tim");

	char 	find[] = "assdf";
	char 	strin[] = "as";
	char 	*temp = ft_strstr(strin, find);
	printf("temp: %s\n", temp);
	printf("final: %s\n", strin);


/*	char *ds = "asdfdddd";
	const char *sr = "zxcx";
	size_t si = 3;
	printf("cat: %lu", strlcat(ds, sr, si));
	return 0;
*/
}


// %s = string
// %d = int

// %f = double
// %c = char
