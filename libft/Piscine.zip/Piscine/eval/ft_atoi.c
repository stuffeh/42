/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tyeung <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/15 21:46:18 by tyeung            #+#    #+#             */
/*   Updated: 2019/07/15 21:46:21 by tyeung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	atoi(char *str, int ispos)
{
	int count;
	int num;
//2147483648
	count = 0;
	num = 0;
	while (str[count] >= '0' && str[count] <= '9')
	{
		num = 10 * num + (str[count] - '0');
		count++;
	}
	return (num * ispos);
}

int	haswhitespace(char str)
{
	if (str >= 0 && str <=32)
		return (1);
	else
		return (0);
}

int	ft_atoi(char *str)
{
	char	st;
	int		ispos;

	st = str[0];
	ispos = 1;
	while (haswhitespace(st) == 1)
	{
		str++;
		st = str[0];
	}
	if ((str[0] == '+' || (str[0] == '-')) && (str[1] >= '0' && str[1] <= '9'))
	{
		if (*str == '-')
		{
			ispos = -1;
			atoi(str++, ispos);
		}
		else
			atoi(str++, ispos);
	}
	else if(!(str[1] >= '0' && str[1] <= '9'))
		return -1;
	return (atoi(str++, ispos));
}
